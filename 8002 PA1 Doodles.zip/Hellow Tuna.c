/*
Author: Ziming Zhao
Brave new world towards the defense industries.
Sources:
Basic syntax and structure: https://www.cs.umd.edu/~nelson/classes/resources/cstyleguide/
Comments:  https://www.w3schools.com/c/c_comments.php
Print version: https://www.w3resource.com/c-programming-exercises/basic-declarations-and-expressions/c-programming-basic-exercises-2.php
*/

#include <stdio.h>

// prints the meat of the assignment
int main(void) {
    printf("Hello Tuna Fish!\n");
#ifdef __STDC_VERSION__
    printf("C standard: %ld\n", __STDC_VERSION__);
#else
    printf("C standard: C90 or earlier\n");
#endif

    printf("Ziming Zhao\n");

    return 0;

}