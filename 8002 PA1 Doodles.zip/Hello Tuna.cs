
/*
Author: Ziming Zhao
Brave new world towards the defense industries.
Sources:
Basic syntax and structure: https://learn.microsoft.com/en-us/dotnet/csharp/fundamentals/coding-style/coding-conventions
Print version: https://stackoverflow.com/questions/1565434/how-do-i-find-the-installed-net-versions
Comments: https://www.w3schools.com/cs/cs_comments.php

*/


using System;

// prints the meat of the assignment, in the syle guide I found: so his tastes are mine.
class Program
{
    static void Main()
    {
        Console.WriteLine("Hello Tuna Fish!");

        Console.WriteLine($".NET version: {Environment.Version}");

        Console.WriteLine("Ziming Zhao");
    }
}